"""
河南牛价数据 - 自动更新并部署到 Netlify
"""

import os
import sys
import subprocess
import zipfile
import shutil

FOLDER = os.path.dirname(os.path.abspath(__file__))

def update_data():
    """更新数据"""
    print("[1/3] 正在获取最新数据...")
    try:
        sys.path.insert(0, FOLDER)
        import data_update
        print("  ✓ 数据更新成功")
        return True
    except Exception as e:
        print(f"  ✗ 数据更新失败: {e}")
        return False

def deploy_to_netlify():
    """部署到 Netlify"""
    print("[2/3] 正在部署到 Netlify...")

    # 方法1: 使用 Netlify CLI
    try:
        # 检查 netlify CLI 是否安装
        result = subprocess.run(['netlify', '--version'], capture_output=True, text=True)
        if result.returncode != 0:
            print("  正在安装 Netlify CLI...")
            subprocess.run(['npm', 'install', '-g', 'netlify-cli'], capture_output=True)

        # 部署
        print("  正在部署...")
        result = subprocess.run(
            ['netlify', 'deploy', '--prod', '--dir=.'],
            cwd=FOLDER,
            capture_output=True,
            text=True,
            timeout=120
        )

        if result.returncode == 0:
            print("  ✓ 部署成功!")
            return True
        else:
            print(f"  ✗ Netlify CLI 部署失败")
            print(f"  错误: {result.stderr[:200] if result.stderr else '未知错误'}")
            return False

    except FileNotFoundError:
        print("  ✗ Netlify CLI 未安装且无法安装")
        print("  提示: 请先安装 Node.js")
        return False
    except Exception as e:
        print(f"  ✗ 部署出错: {e}")
        return False

def deploy_zip():
    """备用方案：手动打包"""
    print("[2/3] 正在打包网站文件...")
    zip_path = os.path.join(FOLDER, "henan-cattle.zip")

    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk(FOLDER):
            # 排除不需要的文件
            if '.git' in root or 'node_modules' in root or '__pycache__' in root:
                continue
            for file in files:
                if file.endswith(('.zip', '.pyc', '.bat')):
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, FOLDER)
                zipf.write(file_path, arcname)

    print(f"  ✓ 已打包: {zip_path}")
    print("  请手动部署到 Netlify:")
    print("  1. 打开 https://app.netlify.com/drop")
    print("  2. 拖入这个文件夹或上传 zip 文件")
    return True

def main():
    print("=" * 50)
    print("  河南牛价数据 - 自动更新并部署")
    print("=" * 50)
    print()

    # 1. 更新数据
    if not update_data():
        input("\n按回车键退出...")
        return

    print()

    # 2. 尝试部署
    if not deploy_to_netlify():
        print()
        print("Netlify CLI 部署失败，将使用备用方案...")
        deploy_zip()

    print()
    print("=" * 50)
    print("  完成!")
    print("=" * 50)
    print()
    print(f"网站地址: https://dulcet-daifuku-4f5ffe.netlify.app/")

    input("\n按回车键退出...")

if __name__ == '__main__':
    main()
